<template>
    <div class="main">
      <Header />
    <router-view></router-view>
    </div>
</template>
<script>
export default {
  name: "Blank",
}
</script>
